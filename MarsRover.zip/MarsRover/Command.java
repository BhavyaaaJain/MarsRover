/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MarsRover;

/**
 *
 * @author LENOVO
 */
abstract class Command {
    abstract void move(Rover rover, Grid grid);
}
